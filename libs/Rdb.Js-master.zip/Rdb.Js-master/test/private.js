

/**
 * Created by JetBrains WebStorm.
 * User: David
 * Date: 4/15/12
 * Time: 6:48 PM
 * To change this template use File | Settings | File Templates.
 */


var domain = 'dev.rdbhost.com',
    acct_number = 12,
    demo_r_role = 'r0000000012',
    demo_p_role = 'p0000000012',
    demo_s_role = 's0000000012',
    demo_email = 'js@travelbyroad.net';
